# dictionary comprehension with if else
#  d = {1 = 'odd' , 2 : 'even'}

odd_even = {i:('even' if i%2==0 else 'odd') for i in range(1,11)}
print(odd_even)


# more you can do.....remind all facts fromm python docs and w3schhol and geeks for geeks and self notes