# lambda expression (anonymous fuction

def add(a,b):
    return a+b

add2 = lambda a , b : a+b 
print(add2(2,320))

multiply = lambda a,b : a*b
print(multiply(2,3))

print(add)

